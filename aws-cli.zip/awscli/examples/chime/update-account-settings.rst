**To update account settings**

This example disables the remote control of shared screens for the specified Amazon Chime account.

Command::

  aws chime update-account-settings --account-id 12a3456b-7c89-012d-3456-78901e23fg45 --account-settings DisableRemoteControl=true

Output::

  None
