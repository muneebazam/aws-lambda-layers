**To get the details of all Usage Plans**

Command::

  aws apigateway get-usage-plans
